#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/stat.h>
#include <errno.h>
#include <sys/types.h>
#include <dirent.h>
#include <syslog.h>
#include <signal.h>
#include <sys/syslog.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include"header.h"
 
#define BUFSIZE 1024
 
int sleeplenght = 5; //czas trwania drzemki
int filesFound;

int main(int argc,char* argv[])
{
    sigset_t iset, iset2; //zmienne do reprezentowania sygnalow
    struct sigaction sleeper;
    struct sigaction listener;
    int counter,rec=0;
    pid_t pid, sid;
    long int bigFilesize=100000;
    int flag = 1;
    openlog("demon", LOG_PID, LOG_LOCAL1);
 
    if (( argc < 3 ) || ( argc > 6 )) //sprawdzenie ilości podanych argumentow
    {
        syslog(LOG_ERR,"Nie obsluguje tylu argumentow");
        exit(1);
    }

    //sprawdzenie czy do podanych ścieżek jest możliwy dostęp 
    else if (access(argv[1],0) == -1)
    {
        syslog(LOG_ERR,"Sciezka nie istnieje: '%s'\n",argv[1]);
        exit(1);
    }
    else if (access(argv[2],0) == -1)
    {
        syslog(LOG_ERR,"Sciezka nie prowadzi do niczego: '%s'\n",argv[2]);
        exit(1);
    }

    //sprawdzenie czy podane ścieżki są katalogami
    else if ((Patch_is_Dir(argv[1])) != 1) 
    {
        syslog(LOG_ERR,"Tutaj nie ma katalogu: '%s'\n",argv[1]);
        exit(1);
    }
    else if ((Patch_is_Dir(argv[2])) != 1) 
    {
        syslog(LOG_ERR,"Tutaj nie ma katalogu: '%s'\n",argv[2]);
        exit(1);
    }
 
// Obsluga dodatkowych parametrow przekazanych do funkcji
    if (argc > 3)
    {
        for (int i=3; i < argc; i++)
        {
            switch (i)
            {
                case 3: //rekurencyjna synchronizacja katalogów
                    if ((argv[i][0] == '-') || (argv[i][1] == 'R')) rec = 1;
                    break;
                case 4: //parametr określa długość drzemki demona
                    for (counter=0; counter < strlen(argv[i]); ++counter)
                        if (!(isdigit(argv[i][counter]))) flag = 0;

                    if (flag=1) sleeplenght = atoi(argv[i]);
                    break;
                case 5: //parametr określa graniczny rozmiar pliku przy którym zmieniamy metode kopiowania
                    flag = 1;
                    for (counter=0; counter < strlen(argv[i]); ++counter)
                        if (!(isdigit(argv[i][counter]))) flag = 0;

                    if (flag=1) bigFilesize = atoi(argv[i]);
                    break;
                default: break;
            }
        }
    }

	pid = fork();
	if (pid < 0) {
		syslog(LOG_ERR, "Nie udalo sie zrobic PID");
		exit(EXIT_FAILURE);
	}
	if (pid > 0) {
		syslog(LOG_INFO, "Udalo sie zrobic PID");
		exit(EXIT_SUCCESS);
	}
	umask(0);

	sid = setsid();
	if (sid < 0) {
		syslog(LOG_ERR, "Blad przy tworzeniu SID");
		exit(EXIT_FAILURE);	
	}

	/*
	//Odkomentowac, aby przeniesc plik wykonywalny do bezpiecznego folderu "/", aby na kazdym systemie byl dostepny i nie zostal usuniety
        if ((chdir("/")) < 0) {
                syslog(LOG_ERR, "Blad przenoszenia do innego katalogu");
                exit(EXIT_FAILURE);
        }
	else syslog(LOG_INFO, "Udalo sie przeniesc proces do innego katalogu, YUPI :)");
	*/

	//zamykanie standardowych deskryptorow plikow
	close(STDIN_FILENO);
        close(STDOUT_FILENO);
        close(STDERR_FILENO);


    while(1 == 1)
    {
        sigemptyset(&iset);
        sigemptyset(&iset2);
        sleeper.sa_handler = &fsleep;
        sleeper.sa_mask = iset;
        sleeper.sa_flags = 0;
        sigaction(SIGALRM, &sleeper, NULL);
        listener.sa_handler = &fsig;
        listener.sa_mask = iset2;
        listener.sa_flags = 0;
        sigaction(SIGUSR1, &listener, NULL);
        syslog(LOG_INFO,"Ide spac ;)");
        alarm(sleeplenght);
        pause();
        syslog(LOG_INFO,"Wlasie wstalem");
        synchronize(argv[1], argv[2],rec,bigFilesize);
        RemoveExtraFiles(argv[1], argv[2],rec);
    }
    closelog ();
    return 0;
}

int synchronize(char *src, char *dst, int rec, long int bigFilesize)
{
    DIR *catSrc, *catDst;
    struct dirent *dit;
    char srcpath[30], dstpath[30];
    struct stat srcfileinfo, dstfileinfo;
    if (((catSrc = opendir(src)) == NULL) || ((catDst = opendir(dst)) == NULL))
    {
        syslog(LOG_ERR,"Nie moglem otworzyc katalogu\n");
        return -1;
    }
    syslog(LOG_INFO,"Teraz bede synchronizowal dwa katalogi:  %s oraz %s",src,dst);
    while ((dit = readdir(catSrc)) != NULL)
    {
        if( (strcmp(dit->d_name,".")==0) || (strcmp(dit->d_name,"..")==0) ) continue;
        dstfileinfo.st_mtime = 0;
        strcpy(srcpath,src);
        strcpy(dstpath,dst);
        strcat(srcpath,"/");
        strcat(srcpath,dit->d_name);
        strcat(dstpath,"/");
        strcat(dstpath,dit->d_name);
        stat(srcpath,&srcfileinfo);
        stat(dstpath,&dstfileinfo);
        switch (WhatIsIt(srcfileinfo)) //sprawdzamy czy podana sciezka wskazuje na plik czy folder
        {
            case 0: //jeśli ścieżka jest zwykłym plikiem
                if(srcfileinfo.st_mtime > dstfileinfo.st_mtime)
                {
                    if (srcfileinfo.st_size > bigFilesize)
                        copyFile_mmap(srcpath,dstpath,&srcfileinfo);
                    else copyFile(srcpath,dstpath);
                }
                filesFound++;
                break;
            case 1: //jesli ścieżka jest folderem
                if (rec == 1)
                {
                    if (stat(dstpath,&dstfileinfo) == -1) 
                    {
                        mkdir(dstpath,srcfileinfo.st_mode);
                        synchronize(srcpath,dstpath,rec,bigFilesize);
                    }
                    else synchronize(srcpath,dstpath,rec,bigFilesize);
                }
                break;
            default: break;
        }
    }
    syslog(LOG_INFO,"readdir() Znalazlem %i plikow", filesFound);
    filesFound = 0;
    closedir(catDst);
    closedir(catSrc);
    free(dit);
    return 0;
}
  
int copyFile(char *source, char *target)
{
    int zrodlowy, docelowy, fileData;
    char bufor[BUFSIZE];
    zrodlowy = open(source, O_RDONLY);
    docelowy = open(target, O_WRONLY | O_CREAT | O_TRUNC, 0777);
    syslog(LOG_INFO,"Skopiowalem plik %s do %s",source,target);
    do
    {
        fileData = read(zrodlowy, bufor, BUFSIZE);
        if((write(docelowy, bufor, fileData)) < 0)
        {
            syslog(LOG_ERR,"Nie dalem rady zapisac tych danych do pliku :(");
            return -1;
        }

    } while(fileData);
    close(zrodlowy);
    close(docelowy);
    return 0;
}
  
int copyFile_mmap(char *source, char *target, struct stat *st)
{
    int zrodlowy, docelowy;
    char* bufor;
    zrodlowy = open(source, O_RDONLY);
    docelowy = open(target, O_WRONLY | O_CREAT | O_TRUNC, 0777);
    syslog(LOG_INFO,"Do skopiowania pliku z %s do %s wykorzystalem metode mapowania :)",source,target);
    bufor = mmap(0,st->st_size,PROT_READ, MAP_SHARED, zrodlowy, 0);
    if((write(docelowy, bufor, st->st_size)) < 0)
    {
        syslog(LOG_ERR,"Nie dalem rady zapisac tych danych do pliku");
        return -1;
    }
    close(zrodlowy);
    close(docelowy);
    return 0;
}
  
void RemoveExtraFiles(char *src, char *dst, int rec)
{
    DIR *catSrc, *catDst;
    struct dirent *dit;
    char srcpath[30], dstpath[30];
    struct stat srcfileinfo, dstfileinfo;

    dit=malloc(sizeof(struct dirent));
    if (((catDst = opendir(dst)) == NULL))
    {
        syslog(LOG_ERR,"Nie moglem otworzyc katalogu :(\n");
    }
    while((dit = readdir(catDst))!=NULL)
    {
        if( (strcmp(dit->d_name,".")==0) || (strcmp(dit->d_name,"..")==0) ) continue;
        strcpy(srcpath,src);
        strcat(srcpath,"/");
        strcat(srcpath,dit->d_name);
        strcpy(dstpath,dst);
        strcat(dstpath,"/");
        strcat(dstpath,dit->d_name);
        lstat(dstpath,&dstfileinfo);
        if(WhatIsIt(dstfileinfo) == 0)//regularny plik
        {
            if(lstat(srcpath,&srcfileinfo)==0) //istnieje taki plik w docelowym
            {
                if(WhatIsIt(srcfileinfo) != 0)//jezeli nie jest regularnym plikiem
                {
                    unlink(dstpath);
                    syslog(LOG_INFO,"Usunalem plik: %s",dstpath);
                }
            }
            else
            {
                unlink(dstpath);
                syslog(LOG_INFO,"Usunalem plik: %s",dstpath);
            }
        }
        if(WhatIsIt(dstfileinfo) == 1 && rec)//katalog i oprcja -R
        {
            if(lstat(srcpath,&srcfileinfo)==0) // istnieje taki katalog
            {
                if(WhatIsIt(srcfileinfo) == 1)//katalog
                RemoveExtraFiles(srcpath, dstpath,rec);
            }
            else//nie ma takiego katalogu
            {
                RemoveExtraFiles(srcpath, dstpath,rec);
                rmdir(dstpath);
            }
        }
    }
    closedir(catDst);
    free(dit);
}

int WhatIsIt(struct stat info)
{
    if(S_ISDIR(info.st_mode)) return 1;
    else
    if(S_ISREG(info.st_mode)) return 0;
    else return -1;
}
 
void fsleep(int sig)
{
    syslog(LOG_INFO,"Obudzilem sie z drzemki :)");
}
 
void fsig(int sig)
{
    syslog(LOG_INFO,"Obudzil mnie sygnal SIGUSR1, wracam do pracy :)");
}
 
int Patch_is_Dir(char* path)
{
    struct stat info;
    if((stat(path, &info)) < 0)
    {
        syslog(LOG_ERR,"Nie jestem w stanie uzyskac informacji o pliku\n");
        return -1;
    }
    else return WhatIsIt(info);
}
